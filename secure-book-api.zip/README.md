# 📚 Secure Book API with Auth, Rate Limiting & Docker

A starter Node.js + Express.js application for managing books via REST API with:

- ✅ JWT-based Authentication
- ✅ Rate Limiting using `express-rate-limit`
- ✅ Secure Password Handling with `bcrypt`
- ✅ CRUD API for books
- ✅ Docker-ready setup

## 🚀 Features

- **Login with JWT tokens** for protected routes.
- **Create, read, update, delete (CRUD)** operations for books.
- **Rate limiting** to prevent abuse.
- **Secure password storage** using bcrypt hashes.
- **Easily deployable** with Docker.

## 🛠️ Setup & Run Locally

### 1. Clone the Repository

```bash
git clone https://github.com/your-username/secure-book-api.git
cd secure-book-api
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Run the App

```bash
node index.js
```

Server will run on `http://localhost:3000`

## 🔐 API Authentication

Use the `/login` endpoint to receive a JWT token. Send it in the header:

```
Authorization: Bearer <token>
```

Demo credentials:

```json
{
  "username": "admin",
  "password": "admin"
}
```

## 📦 Docker Setup

### 1. Build Docker Image

```bash
docker build -t secure-book-api .
```

### 2. Run Docker Container

```bash
docker run -p 3000:3000 secure-book-api
```

## 📌 Endpoints

| Method | Route          | Description           | Auth Required |
|--------|----------------|-----------------------|---------------|
| POST   | `/login`       | Login and get token   | ❌ No          |
| GET    | `/books`       | Get all books         | ✅ Yes         |
| POST   | `/books`       | Create a book         | ✅ Yes         |
| PUT    | `/books/:id`   | Update a book by ID   | ✅ Yes         |
| DELETE | `/books/:id`   | Delete a book by ID   | ✅ Yes         |

## 🔒 Notes

- Replace the hardcoded secret key with environment variables in production.
- This app uses in-memory data; all data is lost on restart. Use a database for persistence.

## 📄 License

MIT License
