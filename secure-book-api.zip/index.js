// Starter Node.js + Express Project with Auth, CRUD, Rate Limiting, and Docker

const express = require('express');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const app = express();

const PORT = process.env.PORT || 3000;
const SECRET_KEY = 'your-secret-key';

app.use(bodyParser.json());

// Rate Limiting Middleware
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
});

app.use(limiter);

// Dummy users (for demo purposes with hashed password)
const users = [
  {
    username: 'admin',
    password: '$2b$10$xAvIsRxMPlUn4x5VmIq0TeC0rKYpqAKG/kdSfbjV.HQVKAsQkFr7i' // hashed 'admin'
  }
];

// Dummy books data
let books = [];

// Authentication Middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.sendStatus(401);

  jwt.verify(token, SECRET_KEY, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
}

// Login Route
app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username);
  if (!user) return res.status(403).json({ message: 'Invalid credentials' });

  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.status(403).json({ message: 'Invalid credentials' });

  const token = jwt.sign({ username }, SECRET_KEY, { expiresIn: '1h' });
  res.json({ token });
});

// CRUD Operations (Protected Routes)

// Create
app.post('/books', authenticateToken, (req, res) => {
  const book = req.body;
  book.id = books.length + 1;
  books.push(book);
  res.status(201).json(book);
});

// Read All
app.get('/books', authenticateToken, (req, res) => {
  res.json(books);
});

// Update
app.put('/books/:id', authenticateToken, (req, res) => {
  const bookId = parseInt(req.params.id);
  const bookIndex = books.findIndex(b => b.id === bookId);
  if (bookIndex === -1) return res.sendStatus(404);

  books[bookIndex] = { ...books[bookIndex], ...req.body };
  res.json(books[bookIndex]);
});

// Delete
app.delete('/books/:id', authenticateToken, (req, res) => {
  const bookId = parseInt(req.params.id);
  books = books.filter(b => b.id !== bookId);
  res.sendStatus(204);
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
